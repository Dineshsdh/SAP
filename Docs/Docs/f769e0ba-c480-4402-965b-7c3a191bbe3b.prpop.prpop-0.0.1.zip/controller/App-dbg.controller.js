sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("prpop.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  