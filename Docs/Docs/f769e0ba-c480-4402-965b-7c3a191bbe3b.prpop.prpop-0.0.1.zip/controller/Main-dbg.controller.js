sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
function (Controller) {
    "use strict";

    return Controller.extend("prpop.controller.Main", {
        onInit: function () {
            var oModel = this.getOwnerComponent().getModel("dgwService");

            oModel.read("/PRdatas", {
                success: function (oData) {
                    console.log("Cantidad de registros:", oData.results.length);
                    console.log("Datos:", oData.results);
                    

                },
                error: function (oError) {
                    console.log("ERROR");
                    
                    try {
                        var sBody = oError.response.body;
                        var oErrorData = JSON.parse(sBody);
                        var sMsg = oErrorData.error.message.value;
                        var sCode = oErrorData.error.code;
                        
                        console.log("Código de error:", sCode);
                        console.log("Mensaje:", sMsg);


                    } catch (e) {
                        console.log("Error bruto:", oError);
                    }
                }
            });
             oModel.read("/Users", {
                success: function (oData) {
                    console.log("Cantidad de registros:", oData.results.length);
                    console.log("Datos:", oData.results);
                    

                },
                error: function (oError) {
                    console.log("ERROR");
                    
                    try {
                        var sBody = oError.response.body;
                        var oErrorData = JSON.parse(sBody);
                        var sMsg = oErrorData.error.message.value;
                        var sCode = oErrorData.error.code;
                        
                        console.log("Código de error:", sCode);
                        console.log("Mensaje:", sMsg);


                    } catch (e) {
                        console.log("Error bruto:", oError);
                    }
                }
            });
             oModel.read("/F4CurrencySet", {
                success: function (oData) {
                    console.log("Cantidad de registros:", oData.results.length);
                    console.log("Datos:", oData.results);
                    

                },
                error: function (oError) {
                    console.log("ERROR");
                    
                    try {
                        var sBody = oError.response.body;
                        var oErrorData = JSON.parse(sBody);
                        var sMsg = oErrorData.error.message.value;
                        var sCode = oErrorData.error.code;
                        
                        console.log("Código de error:", sCode);
                        console.log("Mensaje:", sMsg);

                    } catch (e) {
                        console.log("Error bruto:", oError);
                    }
                }
            });
             oModel.read("/F4_UOMSet", {
                success: function (oData) {
                    console.log("Cantidad de registros:", oData.results.length);
                    console.log("Datos:", oData.results);
                    

                },
                error: function (oError) {
                    console.log("ERROR");
                    
                    try {
                        var sBody = oError.response.body;
                        var oErrorData = JSON.parse(sBody);
                        var sMsg = oErrorData.error.message.value;
                        var sCode = oErrorData.error.code;
                        
                        console.log("Código de error:", sCode);
                        console.log("Mensaje:", sMsg);


                    } catch (e) {
                        console.log("Error bruto:", oError);
                    }
                }
            });
            //Generica de post
            var oPayload = {
                "PurReqNumber": "",
                "PurReqItemNo": "",
                "MaterialNo": "",
                "SupplierNo": "",
                "OrderQuantity": "",
                "UnitOfMeasure": "",
                "PlantCode": "",
                "PurchasingOrg": "",
                "InfoRecordNo": "",
                "MrpController": "",
                "PurchasingGrp": "",
                "AcctAssignCat": "",
                "ItemCategory": "",
                "EstkzIndicator": "",
                "DocumentStatus": "",
                "DocumentDate": "",   // Ojo: A veces SAP requiere null o fecha real aquí
                "ReleaseDate": "",    // Ojo: A veces SAP requiere null o fecha real aquí
                "DeliveryDate": "",   // Ojo: A veces SAP requiere null o fecha real aquí
                "CreatedByUser": "",
                "DeletionIndic": "",
                "ContractNo": "",
                "ContractItemno": "",
                "DocumentType": "",
                "RequestorUser": "",
                "EmailAddress": ""
            };

            // 2. Change .read to .create
            oModel.create("/PRdatas", oPayload, {
                success: function (oData, response) {
                    // In a CREATE, oData is the single object created, not an array of results
                    console.log("Registro creado con éxito");
                    console.log("Datos del nuevo registro:", oData);
                    console.log("Datos del nuevo respuesta:", response);
                },
                error: function (oError) {
                    console.log("ERROR al crear");
                    
                    try {
                        var sBody = oError.response ? oError.response.body : oError.responseText; // Sometimes response is nested differently
                        var oErrorData = JSON.parse(sBody);
                        
                        // Check if 'error' object exists to avoid crashes
                        if (oErrorData && oErrorData.error) {
                            var sMsg = oErrorData.error.message ? oErrorData.error.message.value : "Sin mensaje";
                            var sCode = oErrorData.error.code || "Sin código";
                            
                            console.log("Código de error:", sCode);
                            console.log("Mensaje:", sMsg);
                        } else {
                            console.log("Error desconocido:", oErrorData);
                        }

                    } catch (e) {
                        console.log("Error bruto (No JSON):", oError);
                    }
                }
            });
        }
    });
});
