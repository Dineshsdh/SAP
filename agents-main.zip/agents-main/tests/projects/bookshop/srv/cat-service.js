import cds from "@sap/cds"

export default class CatalogService extends cds.ApplicationService {
  init() {
    const { Books, ListOfBooks, Authors } = this.entities

    // Add some discount for overstocked books
    this.after("each", ListOfBooks, (book) => {
      if (book.stock > 111) book.title += ` -- 11% discount!`
    })

    // Reduce stock of ordered books if available stock suffices
    this.on("submitOrder", async (req) => {
      let { book: id, quantity } = req.data
      let book = await SELECT.one.from(Books, id, (b) => b.stock)

      // Validate input data
      if (!book) return req.error(404, `Book #${id} doesn't exist`)
      if (quantity < 1) return req.error(400, `quantity has to be 1 or more`)
      if (!book.stock || quantity > book.stock)
        return req.error(409, `${quantity} exceeds stock for book #${id}`)

      // Reduce stock in database and return updated stock value
      await UPDATE(Books, id).with({ stock: (book.stock -= quantity) })
      return book
    })

    // Get current stock level for a book
    this.on("getStock", async (req) => {
      const { book: id } = req.data
      const book = await SELECT.one.from(Books, id, (b) => b.stock)
      if (!book) return req.error(404, `Book #${id} doesn't exist`)
      return book.stock
    })

    this.on("findAuthor", async (req) => {
      const cqn = SELECT.from(Authors).columns("ID", "name", "dateOfBirth")
      cqn.SELECT.search = [{ val: req.data.searchTerm }]
      return await cqn
    })

    this.before("validateOrder", (req) => {
      req.error(400, "book is required", "book")
      req.error(400, "quantity must be positive", "quantity")
    })
    this.on("validateOrder", () => {})

    return super.init()
  }
}
