import cds from "@sap/cds"

const LOG = cds.log("agents")
import registerDefaultAgentHandlers from "./srv/handlers/index.js"
import { patchLangChain } from "./lib/telemetry/tracing.js"
import { slugified } from "./lib/utils/utils.js"
import cds_compile_to_a2a from "./lib/compile.js"
cds.compile.to.a2a = cds_compile_to_a2a

// Enable doc comments in CSN for agent card generation
cds.env.cdsc = { ...cds.env.cdsc, docComment: true }

cds.on("bootstrap", (app) => {
  // Ensure A2A correlation fields are indexed by SAP Cloud Logging
  const cls_fields = ((cds.env.log ??= {}).cls_custom_fields ??= [])
  if (!cls_fields.includes("agent.task.id")) cls_fields.push("agent.task.id")
  if (!cls_fields.includes("agent.context.id")) cls_fields.push("agent.context.id")

  const providers = {
    ["llm-mock"]: {},
    anthropic: {
      opus: "claude-opus-latest",
      sonnet: "claude-sonnet-latest",
      haiku: "claude-haiku-latest",
    },
    aicore: {
      opus: "anthropic--claude-4.8-opus",
      sonnet: "anthropic--claude-4.6-sonnet",
      haiku: "anthropic--claude-4.5-haiku",
    },
  }

  for (const [name, s] of Object.entries(cds.env.requires)) {
    const kind = s?.kind ?? s
    if (typeof kind !== "string") continue
    let [provider, model] = kind.split("/")
    if (name.startsWith("llm") && !providers[provider] && providers["llm-" + provider])
      provider = "llm-" + provider
    if (providers[provider] && model) {
      s.kind = provider
      s.model = providers[provider][model] ?? model
    }
  }

  const profiles = cds.env.profiles || []
  const isDev = profiles.includes("development") && !profiles.includes("production")
  if (!isDev) return
  if (cds.env.server?.index === false) return

  const AGENT_BLOCK = /(<div id="[^"]+-agent">[\s\S]*?<\/h3>)[\s\S]*?<\/ul>\s*<\/div>/g

  app.get("/", (_req, res, next) => {
    const origSend = res.send.bind(res)
    res.send = (body) => {
      if (typeof body === "string") {
        body = body.replace(AGENT_BLOCK, (_m, head) => `${head}\n      </div>`)
      }
      return origSend(body)
    }
    next()
  })
})

!(function cds_agents_config_compat() {
  // Also support legacy `cds.agents.pool` configuration by merging it into `cds.agents.quotas`
  if (cds.env.agents?.pool)
    cds.env.agents.quotas = { ...cds.env.agents.quotas, ...cds.env.agents.pool }
})()

!(function cds_requires_llm() {
  cds.on("served", async () => {
    const kind = cds.requires.llm?.kind ?? cds.requires.llm
    if (kind === "auto") {
      const { resolve_config } = await import("./lib/config/local.js")
      cds.env.requires.llm = resolve_config({ kind: "auto" })
    }
    if (kind === "anthropic") {
      const { resolve_anthropic_config } = await import("./lib/config/local.js")
      cds.env.requires.llm = resolve_anthropic_config(cds.requires.llm)
    }
    if (kind === "openai") {
      const { resolve_openai_config } = await import("./lib/config/local.js")
      cds.env.requires.llm = resolve_openai_config(cds.requires.llm)
    }

    const config = cds.requires.llm,
      credentials = {}
    const { url, destination, anthropicApiUrl, baseURL, apiKey } = config?.credentials || {}
    if (url) credentials.url = url
    if (destination) credentials.destination = destination
    if (anthropicApiUrl) credentials.anthropicApiUrl = anthropicApiUrl
    if (baseURL) credentials.baseURL = baseURL
    if (apiKey) credentials.apiKey = "***"
    LOG.info(`cds.connect.to 'llm' with:`, { ...config, credentials })
  })
})()

!(function add_agent_handlers() {
  cds.on("serving", (srv) => {
    if (srv.definition?.protocols?.agent) registerDefaultAgentHandlers(srv)
  })
})()

if (cds.env.requires?.telemetry)
  !(function telemetry() {
    // Schedule active_users metric computation + MLflow exporter
    cds.on("served", async () => {
      const { setupActiveUsersMetric } = await import("./lib/telemetry/active-users.js")
      const { setupTraceScrubbing } = await import("./lib/telemetry/span-masking.js")
      setupActiveUsersMetric()
      await setupTraceScrubbing()
      // Defer LangChain patching so the CDS model is fully loaded before patches land.
      // opt-out via cds.env.agents.trace_langchain = false
      if (cds.env.agents?.trace_langchain !== false) {
        await patchLangChain()
      }

      if (cds.env.agents?.mlflow) {
        const { setupMlflowExporter } = await import("./lib/telemetry/mlflow/index.js")
        setupMlflowExporter()
      }
    })
  })()

// Bootstrap sidecar mode when the agent-sidecar profile is active
if (cds.env.profiles?.includes("agent-sidecar"))
  !(function sidecar() {
    // Auto-mark @agent services as external so CDS does not serve them locally.
    // Auto-mark them as hcql services served externally, they are served from the main app.
    // This runs after model load but before cds.serve() filters definitions,
    // so users don't need to add these things manually.
    cds.on("loaded", (csn) => {
      const hcql = cds.requires.kinds["hcql"]
      const agentSidecar = cds.requires.agent || {}
      const hcqlBase = agentSidecar.url // For local development the base URL is given in the package.json
      const agentCredentials = agentSidecar.credentials || {}
      for (const [name, def] of Object.entries(csn.definitions || {})) {
        if (def.kind !== "service") continue
        if (!def["@agent"]) continue
        // Mark as external so CDS does not serve it locally — it will be served via HCQL from the main app.
        def["@cds.external"] = true
        // Java main apps use the CDS service name in the HCQL path (/hcql/CatalogService),
        // Node.js main apps use the slugified path (/hcql/catalog).
        const isJava = !cds.env.profiles?.includes("node")
        let n = isJava ? name : slugified(name)
        if (cds.requires[name]) continue // skip if user provided service-specific config for this service
        if (cds.requires[n]) continue // skip if user provided service-specific config for possibly the slugified version
        const newRequiresEntry = { ...hcql, kind: "hcql" }
        newRequiresEntry.credentials = {
          ...agentCredentials,
          ...(hcqlBase && { url: `${hcqlBase}/${n.split(".").pop()}` }),
          ...(agentCredentials.destination && { path: `/${n.split(".").pop()}` }),
        }
        cds.requires[n] = newRequiresEntry
      }
    })

    cds.on("served", async () => {
      const { bootstrapSidecar } = await import("./lib/sidecar.js")
      await bootstrapSidecar()
    })
  })()
