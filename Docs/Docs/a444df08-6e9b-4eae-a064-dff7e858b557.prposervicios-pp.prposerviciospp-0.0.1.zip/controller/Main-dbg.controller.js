sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/MessageToast",
  "sap/ui/model/json/JSONModel",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/model/FilterType",
  "sap/ui/export/Spreadsheet",
  "prposervicios/model/formatter"
], function (Controller, MessageToast, JSONModel, Filter, FilterOperator, FilterType, Spreadsheet, formatter) {
  "use strict";

  return Controller.extend("prposervicios.controller.Main", {
    formatter: formatter,
    _busyCount: 0,

    onInit: function () {
      this._simCache = new Map();
      this._busyCount = 0;
      var oViewModel = new JSONModel({
        selectedCount: 0,
        pageSize: 10,
        busy: false,
        busySim: false,
        simStatusFilter: "ALL",
        prStatusFilter: "ALL"
      });
      this.getView().setModel(oViewModel, "ui");
      this._applyPRPageSize(oViewModel.getProperty("/pageSize"));
      
      this.getView().setModel(new JSONModel({
        rows: [],
        allRows: [],
        loadedCount: 0,
        totalCount: 0
      }), "prLocal");

      this.getView().addEventDelegate({
        onAfterRendering: async () => {
          await this._loadPRsToLocal();
          this._setupAutoSimulation();
          this._simulateVisibleRows();
        }
      });

      this._setDefaultLast30DaysPO();
      this._rebindPO();
    },

    _makeKey: function (r) {
      return `${r.PurReqNumber}:${r.PurReqItemNo}`;
    },

    _snapshotSimToCache: function () {
      const aAll = this.getView().getModel("prLocal").getProperty("/allRows") || [];
      aAll.forEach(r => {
        const key = this._makeKey(r);
        this._simCache.set(key, {
          SimulationState: r.SimulationState,
          SimulationError: !!r.SimulationError,
          SimulationWarn:  !!r.SimulationWarn,
          SimulationLogs:  Array.isArray(r.SimulationLogs) ? r.SimulationLogs.slice() : []
        });
      });
    },

    onPOAfterVariantLoad: function () {
      this._setDefaultLast30DaysPO();
      this._rebindPO();
    },

    _busyOn: function (sText) {
      if (!Number.isFinite(this._busyCount)) this._busyCount = 0;   
      this._busyCount++;

      const oUi = this.getView().getModel("ui");
      oUi.setProperty("/busyText", sText || "Loading...");
      oUi.setProperty("/busy", true);
    },

    _busyOff: function () {
      if (!Number.isFinite(this._busyCount)) this._busyCount = 0;   
      this._busyCount = Math.max(0, this._busyCount - 1);

      if (this._busyCount === 0) {
        const oUi = this.getView().getModel("ui");
        oUi.setProperty("/busy", false);
        oUi.setProperty("/busyText", "");
      }
    },

    _setupAutoSimulation: function () {
      this._autoSimSetup = true;
    },

    _loadPRsToLocal: async function () {
      const oView = this.getView();
      this._busyOn("Loading PR data...");

      try {
        const oODataModel = oView.getModel(); 
        if (!oODataModel || !oODataModel.bindList) {
          throw new Error("Default OData V4 model not ready on view (getModel() is empty or has no bindList).");
        }

        const oListBinding = oODataModel.bindList("/PRdatas");

        const aCtx = await oListBinding.requestContexts(0, 10000); 
        let aRows = aCtx.map(c => c.getObject()).map(r => {
          const key = `${r.PurReqNumber}:${r.PurReqItemNo}`;
          const cached = this._simCache.get(key);

          return {
            ...r,
            SimulationState: cached?.SimulationState || "NEW",
            SimulationError: cached?.SimulationError || false,
            SimulationWarn:  cached?.SimulationWarn  || false,
            SimulationLogs:  cached?.SimulationLogs  ? cached.SimulationLogs.slice() : []
          };
        });

        const oPR = this.getView().getModel("prLocal");
        const iPageSize = this.getView().getModel("ui").getProperty("/pageSize") || 10;

        oPR.setProperty("/allRows", aRows);
        oPR.setProperty("/totalCount", aRows.length);
        oPR.setProperty("/loadedCount", Math.min(iPageSize, aRows.length));
        oPR.setProperty("/rows", aRows.slice(0, iPageSize));

        this._buildPRFilterBarFromData(aRows);

      } catch (e) {
        console.error("Failed loading PRs to local model:", e);
        sap.m.MessageToast.show("Failed loading PRs: " + (e.message || e));
        oView.getModel("prLocal")?.setProperty("/rows", []);
      } finally{
        this._busyOff();
      }
    },

    onSimStatusChange: function () {
      this._applyPRFiltersFromFilterBar(); 
    },

    _isSimError: function (oRow) {
      return oRow.SimulationState === "DONE" && !!oRow.SimulationError;
    },

    _isSimSuccess: function (oRow) {
      return oRow.SimulationState === "DONE" && !oRow.SimulationError;
    },

    _buildPRFilterBarFromData: function (aRows) {
      const oFB = this.byId("prFilterBar");
      if (!oFB) return;

      if (this._prFiltersBuilt) return;
      this._prFiltersBuilt = true;

      const aExclude = ["UserName", "DeletionIndic", "UnDeletionIndic", "MaterialDesc", "SupplierNo"];

      const aDefaultVisible = [
        "PurReqNumber",
        "MaterialNo",
        "PurchasingOrg",
        "MrpController",
        "PurchasingGrp",
        "FixedVendor"
      ];

      const aForced = []; 

      const oSample = (aRows && aRows.length) ? aRows[0] : {};
      const aFields = Array.from(new Set([
        ...Object.keys(oSample || {}),
        ...aForced
      ])).filter(f => !aExclude.includes(f));

      aFields.sort((a, b) => {
        const ia = aDefaultVisible.includes(a) ? 0 : 1;
        const ib = aDefaultVisible.includes(b) ? 0 : 1;
        if (ia !== ib) return ia - ib;
        return a.localeCompare(b);
      });

      const isDateField = (sField) => ["DocumentDate", "ReleaseDate", "DeliveryDate"].includes(sField);

      aFields.forEach((sField) => {
        const bVisible = aDefaultVisible.includes(sField);

        const oControl = isDateField(sField)
          ? new sap.m.DateRangeSelection({
              width: "18rem",
              placeholder: "From - To",
              change: this.onPRFilterImmediateChange.bind(this)
            })
          : new sap.m.Input({
              width: "14rem",
              placeholder: "Enter " + sField,
              liveChange: this.onPRFilterImmediateChange.bind(this)
            });
        
        oControl.data("field", sField);

        const oFGI = new sap.ui.comp.filterbar.FilterGroupItem({
          name: sField,
          label: this._labelForPRField(sField),
          groupName: "Group1",
          visibleInFilterBar: bVisible,
          control: oControl
        });

        oFB.addFilterGroupItem(oFGI);
      });
    },

    _formatPRLogsForExport: function (aLogs) {
      if (!Array.isArray(aLogs) || aLogs.length === 0) return "";

      const aErr = aLogs.filter(l => String(l?.type || "").toUpperCase() === "E");
      if (!aErr.length) return "";

      return aErr
        .map(l => {
          const msg = l?.text || l?.message || "";
          return `[E] ${msg}`;
        })
        .join("\n");
    },

    onExportPRsToExcel: function () {
      const oTable = this.byId("prTable");
      if (!oTable) return;

      const oPR = this.getView().getModel("prLocal");
      const aAllRows = (oPR && oPR.getProperty("/allRows")) || [];
      if (!aAllRows.length) {
        sap.m.MessageToast.show("No data to export.");
        return;
      }

      const aSelIdx = (oTable.getSelectedIndices && oTable.getSelectedIndices()) || [];
      let aExportRows;

      if (aSelIdx.length > 0) {
        aExportRows = aSelIdx
          .map(i => aAllRows[i])
          .filter(Boolean);
        if (!aExportRows.length) {
          sap.m.MessageToast.show("Selection is empty.");
          return;
        }
      } else {
        aExportRows = aAllRows;
      }

      const aExportRowsFinal = aExportRows.map(r => ({
        ...r,
        ErrorLog: this._formatPRLogsForExport(r.SimulationLogs)
      }));

      const aCols = this._getPRExportColumns();

      const oSheet = new sap.ui.export.Spreadsheet({
        workbook: { columns: aCols },
        dataSource: aExportRowsFinal,
        fileName: aSelIdx.length > 0 ? "PR_Monitor_Selected.xlsx" : "PR_Monitor_All.xlsx"
      });

      oSheet.build().finally(function () {
        oSheet.destroy();
      });
    },

    _getPRExportColumns: function () {
      return [
        { label: "PR", property: "PurReqNumber" },
        { label: "Item", property: "PurReqItemNo" },
        { label: "Material", property: "MaterialNo" },
        { label: "Material Description", property: "MaterialDesc" },
        { label: "Vendor", property: "FixedVendor" },
        { label: "Vendor Name", property: "FixedVendorName" },
        { label: "Plant", property: "PlantCode" },
        { label: "Purchasing Org", property: "PurchasingOrg" },
        { label: "Purchasing Group", property: "PurchasingGrp" },
        { label: "MRP Controller", property: "MrpController" },
        { label: "Document Status", property: "DocumentStatus" },
        { label: "Order Qty", property: "OrderQuantity" },
        { label: "UoM", property: "UnitOfMeasure" },
        { label: "Currency", property: "Currency" },
        { label: "Price", property: "Valuation_Price" },
        { label: "Delivery Date", property: "DeliveryDate" },
        { label: "Release Date", property: "ReleaseDate" },
        { label: "Document Date", property: "DocumentDate" },
        { label: "Email", property: "EmailAddress" },
        { label: "Contract", property: "ContractNo" },
        { label: "Error Log", property: "ErrorLog" }
      ];
    },

    _labelForPRField: function (s) {
      const m = {
        PurReqNumber: "Purchase Requisition",
        PurReqItemNo: "Item",
        PRItemDesc: "PR Item Desc",
        MaterialNo: "Material",
        FixedVendor: "Fixed Vendor",
        FixedVendorName: "Vendor Name",
        PurchasingOrg: "Purch. Org",
        PurchasingGrp: "Purch. Group",
        MrpController: "MRP Ctrl",
        PlantCode: "Plant",
        DocumentStatus: "Doc Status",
        DocumentType: "Doc Type",
        DeliveryDate: "Delivery Date",
        ReleaseDate: "Release Date",
        DocumentDate: "Doc Date",
        OrderQuantity: "Order Qty",
        UnitOfMeasure: "UoM",
        Currency: "Currency",
        Valuation_Price: "Valuation Price",
        CreatedByUser: "Created By",
        RequestorUser: "Requestor",
        EmailAddress: "Email",
        InfoRecordNo: "Info Record",
        AcctAssignCat: "Acct Assign",
        ItemCategory: "Item Category",
        EstkzIndicator: "Estkz",
        ContractNo: "Contract",
        ContractItemno: "Contract Item"
      };
      return m[s] || s;
    },

    _refreshPRLocalFromBackend: async function () {
      this._clearPRSelection();

      this._snapshotSimToCache();
      await this._loadPRsToLocal();              // <-- vuelve a pedir PRdatas

      const oTable = this.byId("prTable");
      oTable?.getBinding("rows")?.refresh(true);
    },

    _attachAutoSimulation: function () {
      const oTable = this.byId("prTable");
      const oBinding = oTable.getBinding("rows");
      if (!oBinding) return;

      const trigger = () => {
        clearTimeout(this._simTimer);
        this._simTimer = setTimeout(() => this._simulateVisibleRows(), 300);
      };

      oBinding.attachDataReceived(trigger);
    },

    _simulateVisibleRows: async function () {
      const oTable = this.byId("prTable");
      if (!oTable) return;

      if (this._simBusy) return;
      this._simBusy = true;
      this.getView().getModel("ui").setProperty("/busySim", true);

      try {
        const iFirst = oTable.getFirstVisibleRow();
        const iCount = oTable.getVisibleRowCount();

        const aUnique = [];
        const mSeen = new Set();

        for (let i = iFirst; i < iFirst + iCount; i++) {
          const oCtx = oTable.getContextByIndex(i);
          if (!oCtx) continue;

          const o = oCtx.getObject();
          if (!o) continue;

          if (o.SimulationState === "DONE") continue;

          const key = `${o.PurReqNumber}:${o.PurReqItemNo}`;
          if (mSeen.has(key)) continue;
          mSeen.add(key);

          aUnique.push({ PurReqNumber: o.PurReqNumber, PurReqItemNo: o.PurReqItemNo });
        }

        for (const t of aUnique) {
          await this._simulateByKey(t);
        }
      } finally {
        this.getView().getModel("ui").setProperty("/busySim", false);
        this._simBusy = false;
      }
    },

    _findContextByKey: function (sPR, sItem) {
      const oTable = this.byId("prTable");
      const oBinding = oTable.getBinding("rows");
      if (!oBinding) return null;

      const iFirst = oTable.getFirstVisibleRow();
      const iCount = oTable.getVisibleRowCount();

      for (let i = iFirst; i < iFirst + iCount; i++) {
        const oCtx = oTable.getContextByIndex(i);
        if (!oCtx) continue;
        if (oCtx.getProperty("PurReqNumber") === sPR && oCtx.getProperty("PurReqItemNo") === sItem) {
          return oCtx;
        }
      }
      return null;
    },

    _simulateByKey: async function (t) {
      const key = `${t.PurReqNumber}:${t.PurReqItemNo}`;

      const oCtxNow = this._findContextByKey(t.PurReqNumber, t.PurReqItemNo);
      if (!oCtxNow) return;

      // pending
      oCtxNow.setProperty("SimulationState", "PENDING");
      oCtxNow.setProperty("SimulationError", false);
      oCtxNow.setProperty("SimulationWarn", false);
      oCtxNow.setProperty("SimulationLogs", []);

      this._simCache.set(key, {
          SimulationState: "DONE",
          SimulationError: false,
          SimulationWarn: false,
          SimulationLogs: []
      });

      try {
        const aReturn = await this._executeCatalogAction("prSimulateSingle", {
          Items: [{
            PurReqNumber: t.PurReqNumber,
            PurReqItemNo: t.PurReqItemNo
          }]
        });

        const aLogs = (aReturn || []).map(m => ({
          type: m.MsgType || "I",
          text: m.MsgText || ""
        }));

        const bError = aLogs.some(l => l.type === "E" || l.type === "A");
        const bWarn  = !bError && aLogs.some(l => l.type === "W");

        const oCtxAgain = this._findContextByKey(t.PurReqNumber, t.PurReqItemNo);
        if (!oCtxAgain) return;

        oCtxAgain.setProperty("SimulationState", "DONE");
        oCtxAgain.setProperty("SimulationError", bError);
        oCtxAgain.setProperty("SimulationWarn", bWarn);
        oCtxAgain.setProperty("SimulationLogs", aLogs);

        this._simCache.set(key, {
          SimulationState: "DONE",
          SimulationError: bError,
          SimulationWarn: bWarn,
          SimulationLogs: aLogs.slice()
        });

      } catch (e) {
        const aFailLogs = [{
          type: "E",
          text: "Simulation request failed: " + (e?.message || e)
        }];

        const oCtxAgain = this._findContextByKey(t.PurReqNumber, t.PurReqItemNo);
        if (oCtxAgain) {
          oCtxAgain.setProperty("SimulationState", "DONE");
          oCtxAgain.setProperty("SimulationError", true);
          oCtxAgain.setProperty("SimulationWarn", false);
          oCtxAgain.setProperty("SimulationLogs", aFailLogs);
        }

        this._simCache.set(key, {
          SimulationState: "DONE",
          SimulationError: true,
          SimulationWarn: false,
          SimulationLogs: aFailLogs
        });

      }
    },

    _simulateOne: async function (oCtx) {
      const o = oCtx.getObject() || {};
      const sQty = String(o.OrderQuantity || "").trim();

      oCtx.setProperty("SimulationState", "PENDING");
      oCtx.setProperty("SimulationError", false);
      oCtx.setProperty("SimulationLogs", []);

      if (!sQty) {
        oCtx.setProperty("SimulationState", "DONE");
        oCtx.setProperty("SimulationError", true);
        oCtx.setProperty("SimulationLogs", [{ type: "E", text: "Missing Order Quantity" }]);
        return;
      }

      try {
        const aReturn = await this._executeCatalogAction("prSimulate", {
          UserName: this._getUserNameForActions(),
          Items: [{
            PurReqNumber: o.PurReqNumber,
            PurReqItemNo: o.PurReqItemNo,
            OrderQuantity: sQty
          }]
        });

        const aLogs = (aReturn || []).map(m => ({
          type: m.MsgType || "I",
          text: m.MsgText || ""
        }));

        const bError = aLogs.some(l => l.type === "E" || l.type === "A");

        oCtx.setProperty("SimulationState", "DONE");
        oCtx.setProperty("SimulationError", bError);
        oCtx.setProperty("SimulationLogs", aLogs);

      } catch (e) {
        oCtx.setProperty("SimulationState", "DONE");
        oCtx.setProperty("SimulationError", true);
        oCtx.setProperty("SimulationLogs", [{
          type: "E",
          text: "Simulation request failed: " + (e?.message || e)
        }]);
      }
    },

    _getPRTable: function () {
      return this.byId("prTable");
    },

    _applyPRPageSize: function (iSize) {
      var oTable = this._getPRTable();
      if (!oTable) return;

      oTable.setVisibleRowCount(iSize);
      oTable.setVisibleRowCountMode("Fixed");
    },

    onPRTableSelectionChange: function (oEvent) {
      var oTable = oEvent.getSource();
      var iCount = oTable.getSelectedIndices().length;
      this.getView().getModel("ui").setProperty("/selectedCount", iCount);
    },

    _getSelectedPRContexts: function () {
      var oTable = this._getPRTable();
      if (!oTable) return [];

      var aIdx = oTable.getSelectedIndices();
      return aIdx.map(function (i) {
        return oTable.getContextByIndex(i);
      }).filter(Boolean);
    },

    _clearPRSelection: function () {
      var oTable = this._getPRTable();
      if (oTable) {
        oTable.clearSelection();
      }
      this.getView().getModel("ui").setProperty("/selectedCount", 0);
    },

    _refreshPRTable: function () {
      var oTable = this._getPRTable();
      if (!oTable) return;

      var oBinding = oTable.getBinding("rows");
      if (oBinding) {
        oBinding.refresh();
      }
    },

    onPRSearch: function () {
      this._applyPRFiltersFromFilterBar();
    },

    onPRFilterChange: function () {
      this._applyPRFiltersFromFilterBar();
    },

    onPRAfterVariantLoad: function () {
      this._applyPRFiltersFromFilterBar();
    },

    onPRFilterImmediateChange: function () {
      clearTimeout(this._prFilterTimer);
      this._prFilterTimer = setTimeout(() => this._applyPRFiltersFromFilterBar(), 150);
    },

    _toYYYYMMDD: function (oDate) {
      const y = String(oDate.getFullYear());
      const m = String(oDate.getMonth() + 1).padStart(2, "0");
      const d = String(oDate.getDate()).padStart(2, "0");
      return y + m + d;
    },

    onPRStatusChange: function () {
      this._applyPRFiltersFromFilterBar();
    },

    _isDeleted: function (oRow) {
      return oRow.DeletionIndic === "X";
    },

    _isOpen: function (oRow) {
      return oRow.DeletionIndic !== "X";
    },

    _applyPRFiltersFromFilterBar: function () {
      const oFB = this.byId("prFilterBar");
      const oPR = this.getView().getModel("prLocal");
      const oUI = this.getView().getModel("ui");
      if (!oFB || !oPR || !oUI) return;

      const aAll = oPR.getProperty("/allRows") || [];
      let aFiltered = aAll.slice();

      const aItems = oFB.getFilterGroupItems() || [];

      // 1) Filtros dinámicos (inputs / date range)
      aItems.forEach((oItem) => {
        const sField = oItem.getName();
        const oCtrl = oItem.getControl();
        if (!oCtrl) return;

        // Ignorá el item del dropdown si lo detectás por name
        if (sField === "SimStatus" || sField === "PRStatus") return;

        if (oCtrl.isA("sap.m.Input")) {
          const sVal = (oCtrl.getValue() || "").trim().toLowerCase();
          if (!sVal) return;

          aFiltered = aFiltered.filter((r) =>
            String(r[sField] ?? "").toLowerCase().includes(sVal)
          );
          return;
        }

        if (oCtrl.isA("sap.m.DateRangeSelection")) {
          const dFrom = oCtrl.getDateValue();
          const dTo = oCtrl.getSecondDateValue();
          if (!dFrom && !dTo) return;

          const dStart = dFrom || dTo;
          const dEnd = dTo || dFrom;

          const sStart = this._toYYYYMMDD(dStart);
          const sEnd = this._toYYYYMMDD(dEnd);

          aFiltered = aFiltered.filter((r) => {
            const v = String(r[sField] ?? "");
            return v >= sStart && v <= sEnd;
          });
          return;
        }
      });

      // 2) Dropdown Simulation Status
      const sSim = oUI.getProperty("/simStatusFilter") || "ALL";
      if (sSim === "ERROR") {
        aFiltered = aFiltered.filter(this._isSimError.bind(this));
      } else if (sSim === "SUCCESS") {
        aFiltered = aFiltered.filter(this._isSimSuccess.bind(this));
      }

      const sPR = oUI.getProperty("/prStatusFilter") || "ALL";
      if (sPR === "DELETED") {
        aFiltered = aFiltered.filter(this._isDeleted.bind(this));
      } else if (sPR === "OPEN") {
        aFiltered = aFiltered.filter(this._isOpen.bind(this));
      }

      oPR.setProperty("/rows", aFiltered);
    },

    onPOTableSelectionChange: function (oEvent) {
      var oTable = oEvent.getSource();
      var iCount = oTable.getSelectedIndices().length;

      this.getView().getModel("ui").setProperty("/selectedCountPO", iCount);
    },

    onCreatePOSingle: async function () {
      var aCtx = this._getSelectedPRContexts();

      if (!aCtx.length) {
        MessageToast.show("Please select at least one PR.");
        return;
      }

      const aNav = aCtx.map(oCtx => {
        const o = oCtx.getObject();
        return {
          PurReqNumber: o.PurReqNumber || o.PurchaseReq,
          PurReqItemNo: o.PurReqItemNo || o.PurchaseReqItem
        };
      });

      try {
        this.getView().setBusy(true);

        var aReturn = await this._executeCatalogAction("prsToSinglePO", {
          UserName: this._getUserNameForActions(),
          Nav_PRsToPOs: aNav
        });

        this._showBackendMessages(aReturn);
        this._clearPRSelection();
        await this._refreshPRLocalFromBackend();

      } catch (e) {
        console.error("prsToSinglePO failed:", e);
        MessageToast.show("Create PO failed: " + (e.message || e));
      } finally {
        this.getView().setBusy(false);
      }
    },

    onCreatePOMulti: async function () {
      var aCtx = this._getSelectedPRContexts();

      if (!aCtx.length) {
        MessageToast.show("Please select at least one PR.");
        return;
      }

      var aNav = aCtx.map(function (oCtx) {
        var o = oCtx.getObject();
        return {
          PurReqNumber: o.PurReqNumber || o.PurchaseReq,
          PurReqItemNo: o.PurReqItemNo || o.PurchaseReqItem
        };
      });

      try {
        this.getView().setBusy(true);

        var aReturn = await this._executeCatalogAction("prsToMultiplePO", {
          UserName: this._getUserNameForActions(),
          Nav_PRsToPOs: aNav
        });

        this._showBackendMessages(aReturn);

        this._clearPRSelection();
        await this._refreshPRLocalFromBackend();

      } catch (e) {
        console.error("prsToMultiplePO failed:", e);
        MessageToast.show("Create Multiple POs failed: " + (e.message || e));
      } finally {
        this.getView().setBusy(false);
      }
    },

    _buildSimulationItemsFromSelection: function () {
      const aCtx = this._getSelectedPRContexts();
      if (!aCtx.length) {
        MessageToast.show("Please select at least one PR to simulate.");
        return null;
      }

      const aItems = aCtx.map((oCtx) => {
        const o = oCtx.getObject() || {};
        return {
          PurReqNumber: o.PurReqNumber,
          PurReqItemNo: o.PurReqItemNo,
          OrderQuantity: String(o.OrderQuantity || "").trim()
        };
      });

      const bMissingQty = aItems.some(it => !it.OrderQuantity);
      if (bMissingQty) {
        MessageToast.show("Simulation requires Order Quantity on all selected rows.");
        return null;
      }

      return aItems;
    },

    _runSimulation: async function (sActionName) {
      const aItems = this._buildSimulationItemsFromSelection();
      if (!aItems) return;

      try {
        this.getView().setBusy(true);

        const aReturn = await this._executeCatalogAction(sActionName, {
          Items: aItems
        });

        this._showBackendMessages(aReturn);
        this._clearPRSelection();
      } catch (e) {
        console.error(sActionName + " failed:", e);
        MessageToast.show("Simulation failed: " + (e.message || e));
      } finally {
        this.getView().setBusy(false);
      }
    },

    onSimulateSingle: function () {
      return this._runSimulation("prSimulateSingle");
    },

    onSimulateMultiple: function () {
      return this._runSimulation("prSimulateMultiple");
    },

    onEditPR: async function () {
      var aCtx = this._getSelectedPRContexts();

      if (aCtx.length !== 1) {
        MessageToast.show("Please select only one row to edit.");
        return;
      }

      await this._openEditPRDialog(aCtx[0]);
    },

    _openEditPRDialog: async function (oCtx) {
      if (!this._oEditPRDialog) {
        this._oEditPRDialog = await sap.ui.core.Fragment.load({
          id: this.getView().getId(),
          name: "prposervicios.view.fragments.EditPRDialog",
          controller: this
        });
        this.getView().addDependent(this._oEditPRDialog);
      }

      this._oEditCtx = oCtx;

      var oData = Object.assign({}, oCtx.getObject());

      var oEditModel = new sap.ui.model.json.JSONModel(oData); 
      this.getView().setModel(oEditModel, "edit");

      this._oEditPRDialog.open();
    },

    onCancelEditPR: function () {
      if (this._oEditPRDialog) {
        this._oEditPRDialog.close();
      }
    },

    onDeletePR: async function () {
      var aCtx = this._getSelectedPRContexts();
      if (!aCtx.length) {
        MessageToast.show("Please select at least one row to delete.");
        return;
      }

      var aItems = aCtx.map(function (oCtx) {
        var o = oCtx.getObject();
        return {
          PurReqNumber: o.PurchaseReq || o.PurReqNumber,
          PurReqItemNo: o.PurchaseReqItem || o.PurReqItemNo
        };
      });

      console.log("Delete request items:", aItems);
      console.log("Selected row object (pre-delete):", aCtx[0].getObject());

      var sUserName = this._getUserNameForActions();

      try {
        this.getView().setBusy(true);

        var aReturn = await this._executeCatalogAction("prDelete", {
          UserName: sUserName,
          Items: aItems
        });

        console.log("Backend messages:", aReturn);

        this._showBackendMessages(aReturn);

        this._clearPRSelection();
        await this._refreshPRLocalFromBackend();

      } catch (e) {
        console.error("prDelete failed:", e);
        MessageToast.show("Delete failed: " + (e.message || e));
      } finally {
        this.getView().setBusy(false);
      }
    },

    _executeCatalogAction: async function (sActionName, mParams) {
      var oModel = this.getView().getModel(); 
      if (!oModel) throw new Error("No default OData V4 model found on the view.");

      try {
        return await this._executeActionPath("/" + sActionName + "(...)", mParams, oModel);
      } catch (e1) {
        return await this._executeActionPath("/CatalogService." + sActionName + "(...)", mParams, oModel);
      }
    },

    _executeActionPath: async function (sPath, mParams, oModel) {
      var oAction = oModel.bindContext(sPath);

      Object.keys(mParams || {}).forEach(function (k) {
        oAction.setParameter(k, mParams[k]);
      });

      await oAction.execute();

      var oResult = oAction.getBoundContext().getObject();
      if (Array.isArray(oResult)) return oResult;
      if (oResult && Array.isArray(oResult.value)) return oResult.value;
      return oResult ? [oResult] : [];
    },

    _showBackendMessages: function (aMsgs) {
      if (!Array.isArray(aMsgs) || !aMsgs.length) {
        MessageToast.show("Operation completed.");
        return;
      }

      var bHasError = aMsgs.some(function (m) {
        var t = String(m.MsgType || "").toUpperCase();
        return t === "E" || t === "A";
      });

      if (bHasError) {
        MessageToast.show("Operation finished with errors. Check console.");
        console.error("Backend messages:", aMsgs);
      } else {
        MessageToast.show(aMsgs[0].MsgText || "Operation completed.");
        console.log("Backend messages:", aMsgs);
      }
    },

    _getUserNameForActions: function () {
      try {
        if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getUser) {
          var sId = sap.ushell.Container.getUser().getId();
          if (sId) return sId;
        }
      } catch (e) {
        // ignore
      }

      // Fallback user hardcodeado en el CAP
      return "1309034";
    },

    onUndeletePR: async function () {
      var aCtx = this._getSelectedPRContexts();
      if (!aCtx.length) {
        MessageToast.show("Please select at least one row to undelete.");
        return;
      }

      var aDeletedCtx = aCtx.filter(function (oCtx) {
        var o = oCtx.getObject();
        return String(o.DeletionIndic || "").toUpperCase() === "X";
      });

      if (!aDeletedCtx.length) {
        MessageToast.show("No deleted PRs selected.");
        return;
      }

      var aItems = aDeletedCtx.map(function (oCtx) {
        var o = oCtx.getObject();
        return {
          PurReqNumber: o.PurReqNumber,
          PurReqItemNo: o.PurReqItemNo
        };
      });

      var sUserName = this._getUserNameForActions();

      try {
        this.getView().setBusy(true);

        var aReturn = await this._executeCatalogAction("prUndelete", {
          UserName: sUserName,
          Items: aItems
        });

        this._showBackendMessages(aReturn);

        this._clearPRSelection();

        await this._refreshPRLocalFromBackend();

      } catch (e) {
        console.error("prUndelete failed:", e);
        MessageToast.show("Undelete failed: " + (e.message || e));
      } finally {
        this.getView().setBusy(false);
      }
    },
    _padVendor10: function (v) {
      return v ? String(v).padStart(10, "0") : v;
    },

    onSaveEditPR: async function () {
      var oEdit = this.getView().getModel("edit")?.getProperty("/");
      if (!oEdit) {
        MessageToast.show("No edit data.");
        return;
      }

      var aItems = [{
        PurReqNumber: oEdit.PurReqNumber,
        PurReqItemNo: oEdit.PurReqItemNo,
        MaterialNo: (oEdit.MaterialNo || "").trim(),
        PRItemDesc: (oEdit.PRItemDesc || "").trim(),   // <-- nuevo
        FixedVendor: this._padVendor10((oEdit.FixedVendor || "").trim()),                          
        OrderQuantity: String(oEdit.OrderQuantity || "").trim(),
        DeliveryDate: String(oEdit.DeliveryDate || "").trim()
      }];

      try {
        this.getView().setBusy(true);

        var aReturn = await this._executeCatalogAction("prChange", {
          UserName: this._getUserNameForActions(),
          Items: aItems
        });

        this._showBackendMessages(aReturn);

        var bHasError = Array.isArray(aReturn) && aReturn.some(function (m) {
          var t = String(m.MsgType || "").toUpperCase();
          return t === "E" || t === "A";
        });

        if (!bHasError) {
          this._oEditPRDialog.close();
          await this._refreshPRLocalFromBackend();
        }
      } catch (e) {
        console.error("prChange failed:", e);
        MessageToast.show("Save failed: " + (e.message || e));
      } finally {
        this.getView().setBusy(false);
      }
    },

    onFixedVendorValueHelp: async function () {
      await this._getFixedVendorVHD();
      await this._applyFixedVendorVHFilters();
      this._oFixedVendorVHD.open();
    },

    _getFixedVendorVHD: async function () {
      if (this._oFixedVendorVHD) return;

      const oView = this.getView();

      await new Promise((resolve) => {
        sap.ui.require(
          ["sap/ui/comp/valuehelpdialog/ValueHelpDialog"],
          (ValueHelpDialog) => {

            this._oFixedVendorVHD = new ValueHelpDialog({
              title: "Select Fixed Vendor",
              supportMultiselect: false,
              supportRanges: false,
              supportRangesOnly: false,
              key: "FixedVendor",
              descriptionKey: "FixedVendor",
              ok: (oEvent) => {
                const aTokens = oEvent.getParameter("tokens") || [];
                const sKey = aTokens[0]?.getKey?.() || "";
                oView.getModel("edit").setProperty("/FixedVendor", sKey);
                this._oFixedVendorVHD.close();
              },
              cancel: () => this._oFixedVendorVHD.close()
            });

            oView.addDependent(this._oFixedVendorVHD);

            // Table
            const oTable = this._oFixedVendorVHD.getTable();

            // Modelo JSON para las filas del VH
            this._oFixedVendorVHModel = new sap.ui.model.json.JSONModel({ rows: [] });
            oTable.setModel(this._oFixedVendorVHModel, "vh");
            oTable.bindRows({ path: "vh>/rows" });

            oTable.addColumn(new sap.ui.table.Column({
              label: new sap.m.Label({ text: "Vendor" }),
              template: new sap.m.Text({ text: "{vh>FixedVendor}" }),
              width: "10rem"
            }));

            oTable.addColumn(new sap.ui.table.Column({
              label: new sap.m.Label({ text: "Material" }),
              template: new sap.m.Text({ text: "{vh>Material}" }),
              width: "12rem"
            }));

            oTable.addColumn(new sap.ui.table.Column({
              label: new sap.m.Label({ text: "Plant" }),
              template: new sap.m.Text({ text: "{vh>Plant}" }),
              width: "6rem"
            }));

            resolve();
          }
        );
      });
    },

    _applyFixedVendorVHFilters: async function () {
      const oEdit = this.getView().getModel("edit")?.getProperty("/") || {};
      const sMaterial = (oEdit.MaterialNo || "").trim();
      const sPlant = (oEdit.PlantCode || "").trim();

      if (!sMaterial || !sPlant) {
        this._oFixedVendorVHModel.setProperty("/rows", []);
        return;
      }

      const esc = (s) => String(s).replace(/'/g, "''");
      const sPath = `/f4Vendors(Material='${esc(sMaterial)}',Plant='${esc(sPlant)}')`;

      try {
        const oODataModel = this.getView().getModel(); // OData V4
        const oOp = oODataModel.bindContext(sPath, null, { $$groupId: "$direct" });
        const oObj = await oOp.requestObject(); // { value:[...] }
        this._oFixedVendorVHModel.setProperty("/rows", oObj?.value || []);
      } catch (e) {
        this._oFixedVendorVHModel.setProperty("/rows", []);
        console.error("f4Vendors failed", e);
      }
    },


    onErrorLog: function () {
      const aCtx = this._getSelectedPRContexts();
      if (aCtx.length !== 1) {
        sap.m.MessageToast.show("Select exactly one PR to see its log.");
        return;
      }

      const aLogs = aCtx[0].getProperty("SimulationLogs") || [];
      if (!aLogs.length) {
        sap.m.MessageToast.show("No logs for this row.");
        return;
      }

      const sText = aLogs.map(l => `[${l.type}] ${l.text || l.message || ""}`).join("\n");
      sap.m.MessageBox.information(sText, { title: "Detailed Error Log" });
    },

    onSendEmail: function () {
      sap.m.URLHelper.triggerEmail("mrp.controller@example.com", "PR Issue", "Please check...");
    },

    onRefresh: async function () {
      try {
        this.getView().setBusy(true);
        await this._refreshPRLocalFromBackend();
        sap.m.MessageToast.show("Refreshed");
      } finally {
        this.getView().setBusy(false);
      }
    },

    _getPOTable: function () {
      return this.byId("poTable");
    },

    _fmtYYYYMMDD: function (oDate) {
      if (!oDate) return null;
      const y = String(oDate.getFullYear());
      const m = String(oDate.getMonth() + 1).padStart(2, "0");
      const d = String(oDate.getDate()).padStart(2, "0");
      return y + m + d;
    },

    _rebindPO: function () {
      const oTable = this.byId("poTable");
      if (!oTable) return;

      const oDRS = this.byId("poCreatedOn");
      const dFrom = oDRS?.getDateValue?.();
      const dTo = oDRS?.getSecondDateValue?.();

      const sFrom = this._fmtYYYYMMDD(dFrom);
      const sTo = this._fmtYYYYMMDD(dTo);

      const oBinding = oTable.getBinding("rows");
      if (!oBinding) return;

      const mParams = {};
      if (sFrom) mParams.FromDate = sFrom;
      if (sTo) mParams.ToDate = sTo;

      oBinding.changeParameters(mParams);
      oBinding.refresh();
    },


    onPOCreatedOnChange: function () {
      this._rebindPO();
    },

    onPOSearch: function () {
      this._rebindPO();
    },

    onRefreshPO: function () {
      this._rebindPO();
      sap.m.MessageToast.show("POs refreshed");
    },

    _setDefaultLast30DaysPO: function () {
      const oDRS = this.byId("poCreatedOn");
      if (!oDRS) return;

      if (oDRS.getDateValue?.() || oDRS.getSecondDateValue?.()) return;

      const to = new Date();
      const from = new Date(to);
      from.setDate(from.getDate() - 30);

      oDRS.setDateValue(from);
      oDRS.setSecondDateValue(to);
    },

    _refreshPO: function () {
      this._rebindPO();
    },

    onExportPOsToExcel: async function () {
      const oTable = this.byId("poTable");
      if (!oTable) return;

      const aSelIdx = (oTable.getSelectedIndices && oTable.getSelectedIndices()) || [];
      let aExportRows = [];

      if (aSelIdx.length > 0) {
        aExportRows = aSelIdx
          .map(i => oTable.getContextByIndex(i))
          .filter(Boolean)
          .map(ctx => ctx.getObject());

        if (!aExportRows.length) {
          sap.m.MessageToast.show("Selection is empty.");
          return;
        }
      } else {
        aExportRows = await this._fetchAllPOsFromBinding(oTable);
        if (!aExportRows.length) {
          sap.m.MessageToast.show("No data to export.");
          return;
        }
      }

      const aCols = this._getPOExportColumns();

      const oSheet = new sap.ui.export.Spreadsheet({
        workbook: { columns: aCols },
        dataSource: aExportRows,
        fileName: aSelIdx.length > 0 ? "PO_Monitor_Selected.xlsx" : "PO_Monitor_All.xlsx"
      });

      oSheet.build().finally(function () {
        oSheet.destroy();
      });
    },

    _fetchAllPOsFromBinding: async function (oTable) {
      const oBinding = oTable.getBinding("rows");
      if (!oBinding) return [];

      const iTop = 1000;
      const aAll = [];

      let iTotal = oBinding.getLength();
      const hasTotal = Number.isFinite(iTotal) && iTotal >= 0;

      for (let skip = 0; ; skip += iTop) {
        const aCtx = await oBinding.requestContexts(skip, iTop);
        const aChunk = (aCtx || []).map(c => c.getObject());
        aAll.push(...aChunk);

        if (hasTotal) {
          if (aAll.length >= iTotal) break;
        } else {
          // fallback: cortamos cuando viene vacío
          if (!aChunk.length) break;
        }
      }

      return aAll;
    },

    _getPOExportColumns: function () {
      return [
        { label: "PO", property: "PONumber" },
        { label: "Line", property: "LineNumber" },
        { label: "Vendor", property: "Vendor" },
        { label: "Vendor Name", property: "VendorName" },
        { label: "PR", property: "PurReqNumber" },
        { label: "PR Item", property: "PurReqItemNo" },
        { label: "PO Qty", property: "POQty" },
        { label: "Plant", property: "Plant" },
        { label: "Created By", property: "CreatedBy" },
        { label: "Created On", property: "CreatedNo" },
        { label: "GRN Status", property: "GRNStatus" },
        { label: "Vendor Conf.", property: "POVendorConfStatus" }
      ];
    },

    onPageSizeChange: function (oEvent) {
      var iSize = parseInt(oEvent.getSource().getSelectedKey(), 10);
      var oUi = this.getView().getModel("ui");
      var oPR = this.getView().getModel("prLocal");

      oUi.setProperty("/pageSize", iSize);
      this._applyPRPageSize(iSize);

      var aAll = oPR.getProperty("/allRows") || [];
      oPR.setProperty("/loadedCount", Math.min(iSize, aAll.length));
      oPR.setProperty("/rows", aAll.slice(0, iSize));

      var oPOTable = this.byId("poTable");
      if (oPOTable) {
        oPOTable.setVisibleRowCount(iSize);
        oPOTable.setVisibleRowCountMode("Fixed");
        var oBinding = oPOTable.getBinding("rows");
        if (oBinding) this._rebindPO();
      }

      this._simulateVisibleRows();
    },

    onLoadMorePRs: function () {
      var oTable = this.byId("prTable");
      var oPR = this.getView().getModel("prLocal");
      var iPageSize = this.getView().getModel("ui").getProperty("/pageSize") || 10;

      var aAll = oPR.getProperty("/allRows") || [];
      var iLoaded = oPR.getProperty("/loadedCount") || 0;

      // guardar posición actual para que no "salte"
      var iFirst = oTable ? oTable.getFirstVisibleRow() : 0;

      var iNewLoaded = Math.min(iLoaded + iPageSize, aAll.length);

      oPR.setProperty("/loadedCount", iNewLoaded);
      oPR.setProperty("/rows", aAll.slice(0, iNewLoaded));

      // restaurar posición
      if (oTable) {
        setTimeout(() => oTable.setFirstVisibleRow(iFirst), 0);
      }

      this._simulateVisibleRows();
    },

    onBeforeExport: function (oEvent) {
      //
    }
  });
});